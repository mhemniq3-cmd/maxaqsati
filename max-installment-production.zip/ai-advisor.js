﻿/**
 * Max AI Sales Advisor Engine v2.0 (مستشار ماكس المالي الذكي)
 * Powered by Google Gemini 2.5 Flash AI + Contextual Arabic NLP
 * Strict Retail Rule: ZERO profit/interest percentage disclosure!
 */

window.MaxAIAdvisor = {
    isOpen: false,
    history: [],     // Conversation memory (multi-turn)
    isProcessing: false,

    // =====================================================
    // GEMINI 2.5 FLASH CONFIG (Editable - Admin Only)
    // =====================================================
    GEMINI_API_KEY: 'AQ.Ab8RN6LH1Lbcq1RZT0I1bGasfpou6k3W-TBM1PrdclHTi3igQQ',
    GEMINI_MODEL: 'gemini-2.5-flash',

    // Device Knowledge Database in IQD
    DEVICE_PRESETS: [
        { keys: ['16 pro max', '١٦ برو ماكس', '16 بروماكس', 'ايفون 16 برو ماكس'], name: 'iPhone 16 Pro Max', price: 1900000 },
        { keys: ['16 pro', '١٦ برو', 'ايفون 16 برو'], name: 'iPhone 16 Pro', price: 1700000 },
        { keys: ['16 plus', '16 بلس', 'ايفون 16 بلس'], name: 'iPhone 16 Plus', price: 1450000 },
        { keys: ['16 عادي', 'ايفون 16', 'iphone 16', '١٦'], name: 'iPhone 16', price: 1300000 },
        { keys: ['15 pro max', '١٥ برو ماكس', '15 بروماكس', 'ايفون 15 برو ماكس'], name: 'iPhone 15 Pro Max', price: 1550000 },
        { keys: ['15 pro', '١٥ برو', 'ايفون 15 برو'], name: 'iPhone 15 Pro', price: 1400000 },
        { keys: ['15 عادي', 'ايفون 15', 'iphone 15', '١٥'], name: 'iPhone 15', price: 1100000 },
        { keys: ['14 pro max', '١٤ برو ماكس', 'ايفون 14 برو ماكس'], name: 'iPhone 14 Pro Max', price: 1300000 },
        { keys: ['14 pro', '١٤ برو', 'ايفون 14 برو'], name: 'iPhone 14 Pro', price: 1150000 },
        { keys: ['14 عادي', 'ايفون 14', 'iphone 14', '١٤'], name: 'iPhone 14', price: 950000 },
        { keys: ['13 pro max', '١٣ برو ماكس', 'ايفون 13 برو ماكس'], name: 'iPhone 13 Pro Max', price: 1050000 },
        { keys: ['13 عادي', 'ايفون 13', 'iphone 13', '١٣'], name: 'iPhone 13', price: 800000 },
        { keys: ['12 pro max', 'ايفون 12 برو ماكس'], name: 'iPhone 12 Pro Max', price: 780000 },
        { keys: ['12', 'ايفون 12'], name: 'iPhone 12', price: 620000 },
        { keys: ['11', 'ايفون 11'], name: 'iPhone 11', price: 500000 },
        { keys: ['s25 ultra', 'اس 25 الترا', 'سامسونج s25 ultra', 's25 الترا'], name: 'Samsung Galaxy S25 Ultra', price: 1850000 },
        { keys: ['s25', 'اس 25'], name: 'Samsung Galaxy S25', price: 1250000 },
        { keys: ['s24 ultra', 'اس 24 الترا', 'سامسونج s24 ultra'], name: 'Samsung Galaxy S24 Ultra', price: 1500000 },
        { keys: ['s24', 'اس 24'], name: 'Samsung Galaxy S24', price: 1050000 },
        { keys: ['s23 ultra', 'اس 23 الترا'], name: 'Samsung Galaxy S23 Ultra', price: 1200000 },
        { keys: ['a55', 'سامسونج a55'], name: 'Samsung Galaxy A55', price: 460000 },
        { keys: ['a35', 'سامسونج a35'], name: 'Samsung Galaxy A35', price: 360000 },
        { keys: ['ps5', 'بلايستيشن 5', 'بلي 5', 'playstation 5', 'سوني 5'], name: 'PlayStation 5 Slim', price: 720000 },
        { keys: ['ps4', 'بلايستيشن 4', 'بلي 4'], name: 'PlayStation 4 Pro', price: 420000 },
        { keys: ['ايباد 10', 'ايباد الجيل العاشر', 'ipad 10'], name: 'iPad 10th Gen', price: 550000 },
        { keys: ['ايباد برو', 'ipad pro'], name: 'iPad Pro M4', price: 1500000 },
        { keys: ['ايباد اير', 'ipad air'], name: 'iPad Air M2', price: 950000 },
        { keys: ['ايباد', 'ipad'], name: 'Apple iPad', price: 550000 },
        { keys: ['ماك بوك', 'macbook'], name: 'Apple MacBook Air M3', price: 1650000 },
        { keys: ['ساعة ابل', 'apple watch'], name: 'Apple Watch Series 10', price: 580000 },
        { keys: ['شاشة', 'تلفزيون'], name: 'شاشة سمارت 4K', price: 450000 },
        { keys: ['سبلت', 'مكيف'], name: 'سبلت 2 طن انفيرتر', price: 850000 },
        { keys: ['ثلاجة', 'ثلاجه'], name: 'ثلاجة إنفيرتر حديثة', price: 750000 },
        { keys: ['غسالة', 'غساله'], name: 'غسالة فول أوتوماتيك', price: 580000 }
    ],

    // =====================================================
    // Build Gemini System Prompt (Dynamic — uses store settings)
    // =====================================================
    buildSystemPrompt() {
        const s = window.AppState;
        const storeName = s?.settings?.storeName || 'مكتب ماكس للتقسيط';
        const storeAddr = s?.settings?.storeAddress || 'بغداد - العراق';
        const storePhone = s?.settings?.storePhone || '07700000000';
        const currentSys = s?.currentSystem === 'manual' ? 'تسديد يدوي' : 'منصة الكترونية';

        // Build a financial context string from DEVICE_PRESETS
        const deviceList = this.DEVICE_PRESETS.slice(0, 12).map(d =>
            `- ${d.name}: ${window.FinanceCalculator ? window.FinanceCalculator.formatNumber(d.price) : d.price} د.ع نقداً`
        ).join('\n');

        return `أنت **مستشار ماكس المالي الذكي**، المستشار الرسمي لـ **${storeName}**.
موقع المكتب: ${storeAddr}
رقم التواصل: ${storePhone}
نظام التقسيط الحالي: ${currentSys}
ساعات العمل: يومياً من 10 صباحاً حتى 10 مساءً

## 🔒 قواعد صارمة لا تخالفها أبداً:
1. تتحدث **باللهجة العراقية العامية** فقط، بشكل طبيعي وودود كأنك موظف مكتب محترف ومتعاون.
2. **ممنوع نهائياً** ذكر أي نسبة مئوية (%) أو كلمة "فائدة" أو "ربح المكتب" أو "زيادة" — ابداً!
3. عندما يسأل الزبون عن الأقساط، اذكر فقط: السعر نقداً، المقدمة (الواصل)، القسط الشهري الصافي، والمجموع الكلي.
4. إذا سألك الزبون عن مقارنة تكنولوجية بين جهازين (مثلاً آيفون vs سامسونج)، أجبه بمقارنة خبيرة ومفيدة بالعامية العراقية وساعده على الاختيار.
5. كن دائماً إيجابياً ومشجعاً وساعد الزبون على اتخاذ القرار الصح.
6. ردودك تكون **مختصرة ومفيدة** وليس طويلة ومملة — 3 إلى 5 جمل كافية في معظم الأحيان.
7. لا تكرر نفسك في كل رسالة.

## 💰 قائمة أسعار الأجهزة النقدية (للرجوع إليها عند الحاجة):
${deviceList}

## 📋 المستمسكات والشروط المطلوبة للتقسيط:
- البطاقة الوطنية الموحدة
- بطاقة الراتب (ماستر/كي كارد) أو كفيل موظف
- بطاقة السكن

## 🚚 التوصيل والخدمة:
نوفر التوصيل والتثبيت لجميع محافظات العراق مع فحص الجهاز عند الاستلام.

## ⚠️ ملاحظة مهمة:
إذا سأل الزبون عن حسبة قسط محددة بالأرقام، اختم ردك بعبارة قصيرة مثل: "تقدر تشوف الحسبة الدقيقة بالحاسبة أعلى الصفحة أو يكلمنا على الواتساب نحسبهالك فوراً 💬" — ولا تذكر أي نسب أو فوائد.`;
    },

    // =====================================================
    // Call Gemini 2.5 Flash API
    // =====================================================
    async callGemini(userMessage) {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.GEMINI_MODEL}:generateContent?key=${this.GEMINI_API_KEY}`;

        // Build conversation history for multi-turn memory (last 6 turns max)
        const recentHistory = this.history.slice(-6).map(h => ({
            role: h.sender === 'user' ? 'user' : 'model',
            parts: [{ text: h.text }]
        })).filter(h => h.parts[0].text && h.parts[0].text.length > 1);

        // Add current message
        recentHistory.push({ role: 'user', parts: [{ text: userMessage }] });

        const body = {
            system_instruction: { parts: [{ text: this.buildSystemPrompt() }] },
            contents: recentHistory,
            generationConfig: {
                maxOutputTokens: 600,
                temperature: 0.75,
                topP: 0.9
            }
        };

        const resp = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        if (!resp.ok) {
            const errData = await resp.json().catch(() => ({}));
            throw new Error(errData?.error?.message || `HTTP ${resp.status}`);
        }

        const data = await resp.json();
        return data?.candidates?.[0]?.content?.parts?.[0]?.text || 'عذراً، لم أتمكن من الرد الآن. حاول مجدداً!';
    },

    // =====================================================
    // Smart Financial Context Detector
    // Detects if Gemini should be followed by a financial card
    // =====================================================
    extractFinancialContext(input) {
        const norm = input.toLowerCase().replace(/[٠-٩]/g, d => '0123456789'['٠١٢٣٤٥٦٧٨٩'.indexOf(d)]);

        let principal = null;
        let downPayment = 0;
        let identifiedProduct = null;

        // Device detection
        for (const preset of this.DEVICE_PRESETS) {
            const isMatch = preset.keys.some(k => norm.includes(k.toLowerCase()) || input.includes(k));
            if (isMatch) {
                identifiedProduct = preset.name;
                principal = preset.price;
                break;
            }
        }

        // Parse amounts
        const parsed = this.parseArabicAmount(input);
        if (parsed && parsed >= 100000) {
            if (/مقدمة|مقدمه|واصل|ادفع/i.test(input)) {
                downPayment = parsed;
            } else if (!principal) {
                principal = parsed;
            }
        }

        // Separate DP
        if (/بدون مقدمة|بدون مقدمه|صفر مقدمة|ما عندي مقدمة|ماكو مقدمة/i.test(input)) {
            downPayment = 0;
        } else {
            const dpMatch = input.match(/(?:مقدمة|مقدمه|واصل|عندي)\s*([^\n,،]{2,20})/i);
            if (dpMatch && dpMatch[1]) {
                const dpVal = this.parseArabicAmount(dpMatch[1]);
                if (dpVal && dpVal < (principal || 5000000) * 0.9) {
                    downPayment = dpVal;
                }
            }
        }

        // Salary detection
        let salary = null;
        const salMatch = input.match(/(?:راتبي|استلم|دخلي|دخلى)\s*([^\n,،]{2,20})/i);
        if (salMatch) {
            const v = this.parseArabicAmount(salMatch[1]);
            if (v) salary = v;
        }

        return { principal, downPayment, identifiedProduct, salary };
    },

    // =====================================================
    // Build a Financial Action Card (if applicable)
    // =====================================================
    buildFinancialCard(ctx) {
        const { principal, downPayment, identifiedProduct, salary } = ctx;
        if (!principal || principal < 100000) return null;

        const s = window.AppState;
        const ratesMap = s.rates?.[s.currentSystem === 'manual' ? 'manual' : 'platform'] ||
                         window.InstallmentData?.DEFAULT_RATES?.platform || {};

        const plans = [10, 12, 14, 16, 18].map(m => {
            const rate = ratesMap[String(m)] ?? 0;
            const calc = window.FinanceCalculator.calculatePlan({
                principal, downPayment, downPaymentType: 'fixed', months: m,
                ratePercent: rate,
                calculationMode: s.settings?.calculationMode || 'flat',
                roundingMode: s.settings?.roundingMode || 'none'
            });
            return { months: m, calc };
        });

        let recommended = plans.find(p => p.months === 12) || plans[0];
        if (salary) {
            const safe = plans.find(p => p.calc.monthlyInstallment <= salary * 0.35);
            if (safe) recommended = safe;
        }

        const plan10 = plans.find(p => p.months === 10);
        const plan18 = plans.find(p => p.months === 18);
        const savings = (plan10 && plan18) ? Math.max(0, plan18.calc.totalRepayment - plan10.calc.totalRepayment) : 0;

        return {
            productName: identifiedProduct || (s.productName || 'الجهاز المطلوب'),
            principal, downPayment,
            months: recommended.months,
            monthly: recommended.calc.monthlyInstallment,
            total: recommended.calc.totalRepayment,
            savings
        };
    },

    // =====================================================
    // Arabic Amount Parser (Iraqi dialect support)
    // =====================================================
    parseArabicAmount(text) {
        if (!text) return null;
        text = text.replace(/[،,]/g, '').trim();
        text = text.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.split('').indexOf(d));

        if (text.includes('مليونين')) {
            let b = 2000000;
            const sub = text.match(/مليونين\s*(?:و|\+)?\s*(\d+|نص|ربع|نصف)?/);
            if (sub?.[1]) {
                if (/نص|نصف/.test(sub[1])) b += 500000;
                else if (/ربع/.test(sub[1])) b += 250000;
                else if (/^\d+$/.test(sub[1])) { const n = +sub[1]; b += n < 1000 ? n * 1000 : n; }
            }
            return b;
        }
        const mM = text.match(/(\d+)?\s*مليون\s*(?:و|\+)?\s*(\d+|نص|ربع|نصف)?/);
        if (mM) {
            let b = (mM[1] ? +mM[1] : 1) * 1000000;
            if (mM[2]) {
                if (/نص|نصف/.test(mM[2])) b += 500000;
                else if (/ربع/.test(mM[2])) b += 250000;
                else if (/^\d+$/.test(mM[2])) { const n = +mM[2]; b += n < 1000 ? n * 1000 : n; }
            }
            return b;
        }
        const kM = text.match(/(\d+)\s*(?:الف|ألف|k)/i);
        if (kM) return +kM[1] * 1000;
        const raw = text.match(/\b(\d{5,8})\b/);
        if (raw) return +raw[1];
        return null;
    },

    // =====================================================
    // INIT
    // =====================================================
    init() {
        const triggerBtn = document.getElementById('aiAdvisorTriggerBtn');
        const closeBtn = document.getElementById('closeAiModalBtn');
        const sendBtn = document.getElementById('aiSendBtn');
        const input = document.getElementById('aiUserInput');

        if (triggerBtn) triggerBtn.addEventListener('click', () => this.toggleModal(true));
        if (closeBtn) closeBtn.addEventListener('click', () => this.toggleModal(false));

        if (sendBtn && input) {
            sendBtn.addEventListener('click', () => this.handleSendMessage());
            input.addEventListener('keydown', e => { if (e.key === 'Enter') this.handleSendMessage(); });
        }

        document.querySelectorAll('.ai-chip-prompt').forEach(chip => {
            chip.addEventListener('click', () => {
                const text = chip.getAttribute('data-prompt') || chip.textContent.trim();
                if (input) input.value = text;
                this.handleSendMessage();
            });
        });
    },

    toggleModal(open) {
        const modal = document.getElementById('aiAdvisorModal');
        const triggerBtn = document.getElementById('aiAdvisorTriggerBtn');
        if (!modal) return;
        this.isOpen = (typeof open === 'boolean') ? open : !this.isOpen;
        if (this.isOpen) {
            modal.classList.remove('hidden');
            if (triggerBtn) triggerBtn.classList.add('scale-0');
            if (window.SoundEngine) window.SoundEngine.playSuccessChime();
            const input = document.getElementById('aiUserInput');
            if (input) setTimeout(() => input.focus(), 150);
            if (this.history.length === 0) this.showWelcomeMessage();
        } else {
            modal.classList.add('hidden');
            if (triggerBtn) triggerBtn.classList.remove('scale-0');
            if (window.SoundEngine) window.SoundEngine.playTick();
        }
    },

    showWelcomeMessage() {
        const storeName = window.AppState?.settings?.storeName || 'مكتب ماكس للتقسيط';
        this.appendMessage('assistant',
            `مرحباً بك في **${storeName}** 💎\n\nأنا **مستشارك المالي الذكي** — مدعوم بـ **Google Gemini AI** 🤖✨\n\nاكتب لي باللهجة العامية وسأجيبك فوراً، سواء كان سؤالاً عن:\n• أقساط أي جهاز 📱\n• مقارنة بين جهازين 🔄\n• الشروط والمستمسكات 📋\n• التوصيل والضمان 🚚\n\n👇 **شنو يخدمك اليوم؟**`
        , null);
    },

    async handleSendMessage() {
        if (this.isProcessing) return;
        const input = document.getElementById('aiUserInput');
        if (!input || !input.value.trim()) return;

        const userText = input.value.trim();
        input.value = '';
        this.isProcessing = true;

        this.appendMessage('user', userText);
        if (window.SoundEngine) window.SoundEngine.playTick();

        this.showTypingIndicator(true);

        try {
            // Call Gemini AI
            const aiReply = await this.callGemini(userText);

            // Save to history for multi-turn memory
            this.history.push({ sender: 'user', text: userText });
            this.history.push({ sender: 'assistant', text: aiReply });

            // Keep history lean (last 20 messages max)
            if (this.history.length > 20) this.history = this.history.slice(-20);

            // Detect if a financial card should be shown
            const ctx = this.extractFinancialContext(userText);
            const actionCard = this.buildFinancialCard(ctx);

            this.showTypingIndicator(false);
            this.appendMessage('assistant', aiReply, actionCard);
            if (window.SoundEngine) window.SoundEngine.playSuccessChime();

        } catch (err) {
            this.showTypingIndicator(false);
            console.error('Gemini API Error:', err);
            this.appendMessage('assistant', `⚠️ عذراً، واجهت مشكلة مؤقتة في الاتصال بالذكاء الاصطناعي.\n\nحاول مجدداً بعد ثانية أو اتصل بنا مباشرة على الواتساب 💬`);
        } finally {
            this.isProcessing = false;
        }
    },

    showTypingIndicator(show) {
        let el = document.getElementById('aiTypingIndicator');
        const container = document.getElementById('aiChatMessages');
        if (!container) return;
        if (show) {
            if (!el) {
                el = document.createElement('div');
                el.id = 'aiTypingIndicator';
                el.className = 'flex items-center gap-2 p-3 rounded-2xl bg-slate-800/60 border border-slate-700/50 w-fit text-slate-400 text-xs';
                el.innerHTML = `
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce"></span>
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.2s]"></span>
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.4s]"></span>
                    <span class="font-medium pr-1">Gemini AI يفكر ويرد عليك...</span>
                `;
                container.appendChild(el);
            }
            container.scrollTop = container.scrollHeight;
        } else {
            if (el) el.remove();
        }
    },

    appendMessage(sender, text, actionCard = null) {
        const container = document.getElementById('aiChatMessages');
        if (!container) return;

        const msgDiv = document.createElement('div');
        msgDiv.className = `flex flex-col ${sender === 'user' ? 'items-end' : 'items-start'} space-y-1.5 animate-fadeIn`;

        const bubble = document.createElement('div');
        if (sender === 'user') {
            bubble.className = 'max-w-[85%] rounded-2xl rounded-br-none p-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs sm:text-sm font-semibold shadow-md leading-relaxed';
            bubble.textContent = text;
        } else {
            bubble.className = 'max-w-[92%] rounded-2xl rounded-bl-none p-4 bg-slate-900 border border-slate-800 text-slate-200 text-xs sm:text-sm leading-relaxed shadow-lg';
            let formatted = text
                .replace(/\*\*(.*?)\*\*/g, '<strong class="text-emerald-400 font-extrabold">$1</strong>')
                .replace(/\*(.*?)\*/g, '<em class="text-slate-300">$1</em>')
                .replace(/•/g, '<span class="text-emerald-500">•</span>')
                .replace(/\n/g, '<br>');
            bubble.innerHTML = formatted;

            // Gemini badge on AI messages
            const badge = document.createElement('div');
            badge.className = 'flex items-center gap-1 mt-2 opacity-50';
            badge.innerHTML = `<span class="text-[9px] text-slate-500 font-mono">✦ Gemini 2.5 Flash AI</span>`;
            bubble.appendChild(badge);
        }

        msgDiv.appendChild(bubble);

        // Financial Action Card
        if (actionCard && sender === 'assistant') {
            const card = document.createElement('div');
            card.className = 'mt-2 p-3.5 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-emerald-500/40 shadow-xl space-y-2.5 max-w-[92%] w-full';
            card.innerHTML = `
                <div class="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span class="text-[11px] font-black text-slate-300">📱 ${actionCard.productName}</span>
                    <span class="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-black font-mono">${actionCard.months} شهر</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-xs">
                    <div class="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
                        <span class="text-[10px] text-slate-400 block mb-0.5">القسط الشهري الصافي:</span>
                        <span class="text-xs sm:text-sm font-black text-emerald-400 font-mono">${window.FinanceCalculator.formatIraqiShort(actionCard.monthly)}</span>
                    </div>
                    <div class="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
                        <span class="text-[10px] text-slate-400 block mb-0.5">المجموع الكلي:</span>
                        <span class="text-xs sm:text-sm font-black text-slate-200 font-mono">${window.FinanceCalculator.formatIraqiShort(actionCard.total)}</span>
                    </div>
                </div>
                ${actionCard.savings > 0 ? `<div class="text-[10px] text-amber-400/80 font-semibold">💡 توفر ${window.FinanceCalculator.formatIraqiShort(actionCard.savings)} إذا اخترت 10 أشهر بدلاً من 18!</div>` : ''}
                <div class="flex items-center gap-2 pt-1">
                    <button type="button" onclick="window.MaxAIAdvisor.applyToCalculator(${actionCard.principal}, ${actionCard.downPayment}, ${actionCard.months}, '${actionCard.productName}')"
                            class="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black transition flex items-center justify-center gap-1.5 shadow-md active:scale-95 cursor-pointer">
                        تطبيق بالحاسبة ⚡
                    </button>
                    <button type="button" onclick="window.MaxAIAdvisor.openWhatsAppForPlan(${actionCard.principal}, ${actionCard.downPayment}, ${actionCard.months}, '${actionCard.productName}', ${actionCard.monthly}, ${actionCard.total})"
                            class="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-emerald-400 text-xs font-black transition flex items-center justify-center gap-1 active:scale-95 cursor-pointer">
                        واتساب 💬
                    </button>
                </div>
            `;
            msgDiv.appendChild(card);
        }

        container.appendChild(msgDiv);
        container.scrollTop = container.scrollHeight;

        if (sender !== 'user') {
            this.history = this.history.filter(h => h.text !== text);
        }
    },

    applyToCalculator(principal, downPayment, months, productName) {
        const s = window.AppState;
        const els = window.AppElements;
        s.principal = principal;
        s.downPayment = downPayment;
        s.selectedPlan = months;
        if (productName) s.productName = productName;
        if (els?.inputPrincipal) els.inputPrincipal.value = principal;
        if (els?.inputDownPayment) els.inputDownPayment.value = downPayment;
        if (els?.inputProductName && productName) els.inputProductName.value = productName;
        this.toggleModal(false);
        if (window.render) window.render();
        if (window.selectPlan) window.selectPlan(months);
        if (window.showToast) window.showToast(`✨ تم تطبيق خطة (${months} شهر) في الحاسبة!`);
    },

    openWhatsAppForPlan(principal, downPayment, months, productName, monthly, total) {
        const storeName = window.AppState?.settings?.storeName || 'مكتب ماكس للتقسيط';
        const dpStr = downPayment > 0 ? window.FinanceCalculator.formatIraqiShort(downPayment) : 'بدون مقدمة';
        const text = encodeURIComponent(
            `السلام عليكم ${storeName} 💎\nأرغب بالاستفسار وحجز:\n` +
            `📱 الجهاز: ${productName || 'جهاز إلكتروني'}\n` +
            `💰 السعر نقداً: ${window.FinanceCalculator.formatNumber(principal)} د.ع\n` +
            `💵 المقدمة: ${dpStr}\n` +
            `🔴 الخطة: ${months} شهر\n` +
            `📆 القسط الشهري: ${window.FinanceCalculator.formatIraqiShort(monthly)}\n` +
            `💳 المجموع الكلي: ${window.FinanceCalculator.formatIraqiShort(total)}\n\n` +
            `يرجى تزويدي بإجراءات الاستلام. شكراً!`
        );
        let phone = window.AppState?.settings?.storePhone || '';
        phone = phone.replace(/\D/g, '');
        if (phone.startsWith('07')) phone = '964' + phone.substring(1);
        const url = phone ? `https://wa.me/${phone}?text=${text}` : `https://wa.me/?text=${text}`;
        window.open(url, '_blank');
    }
};
